<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encontre seu Pet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #4a90e2;
            --secondary-color: #63b3ed;
            --accent-color: #ff6b6b;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
        }
        
        body {
            background-color: #f5f5f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: 600;
            color: white !important;
        }
        
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .nav-link:hover, .nav-link.active {
            color: white !important;
            transform: translateY(-2px);
        }
        
        .hero-section {
            background: linear-gradient(rgba(74, 144, 226, 0.8), rgba(99, 179, 237, 0.8)), 
                        url('https://images.unsplash.com/photo-1450778869180-41d0601e046e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 80px 0;
            border-radius: 0 0 20px 20px;
            margin-bottom: 30px;
        }
        
        .section-title {
            color: var(--dark-color);
            margin-bottom: 25px;
            font-weight: 600;
            position: relative;
            padding-bottom: 10px;
        }
        
        .section-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 400px;
            height: 3px;
            background: var(--primary-color);
        }
        
        .pet-card {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s;
            margin-bottom: 25px;
            background: white;
            cursor: pointer;
        }
        
        .pet-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 20px rgba(0,0,0,0.15);
        }
        
        .pet-card img {
            height: 200px;
            object-fit: cover;
            width: 100%;
        }
        
        .pet-card-body {
            padding: 15px;
        }
        
        .pet-name {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 5px;
        }
        
        .pet-details {
            color: #6c757d;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }
        
        .btn-primary-custom {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 8px;
            padding: 10px 20px;
            color: white;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(74, 144, 226, 0.4);
            color: white;
        }
        
        .lost-pet-section {
            background-color: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .filter-section {
            background-color: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .filter-title {
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--dark-color);
        }
        
        .filter-option {
            margin-bottom: 10px;
        }
        
        .animal-detail-section {
            background-color: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .animal-image {
            width: 100%;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        
        .animal-name {
            font-weight: 700;
            color: var(--dark-color);
            font-size: 1.8rem;
            margin-bottom: 10px;
        }
        
        .animal-info {
            margin-bottom: 15px;
        }
        
        .info-label {
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .pagination-custom .page-link {
            color: var(--primary-color);
            border: 1px solid #dee2e6;
        }
        
        .pagination-custom .page-item.active .page-link {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .page-container {
            display: block;
        }
        
        .page-container.hidden {
            display: none;
        }
        
        .profile-icon {
            font-size: 1.5rem;
            color: white;
            transition: all 0.3s;
        }
        
        .profile-icon:hover {
            color: #ffd700;
        }
        
        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 30px 0;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="bi bi-heart-fill me-2"></i>Auchei Miauamigo
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#" onclick="showPage('home-page')">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" onclick="showPage('adoption-page')">Adotar animal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">ONGs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Animais perdidos</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#" onclick="showPage('profile-page')">
                            <i class="bi bi-person-circle profile-icon"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Página Principal -->
    <div id="home-page" class="page-container">
        <!-- Hero Section -->
        <section class="hero-section">
            <div class="container text-center">
                <h1 class="display-4 fw-bold mb-4">Encontre seu amigo</h1>
                <p class="lead mb-4">Conectamos pets adoráveis a lares cheios de amor</p>
                <button class="btn btn-light btn-lg px-4 py-2 fw-bold" onclick="showPage('adoption-page')">Encontrar um pet</button>
            </div>
        </section>

        <div class="container">
            <!-- Seção "Meu amigo desapareceu" -->
            <section class="lost-pet-section">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2 class="section-title">Meu amigo desapareceu</h2>
                        <p class="mb-4">Ajude outras pessoas a acharem o amigo perdido 😊</p>
                        <button class="btn btn-primary-custom">Reportar animal perdido</button>
                    </div>
                    <div class="col-md-4 text-center">
                        <i class="bi bi-search display-1 text-primary"></i>
                    </div>
                </div>
            </section>

            <!-- Seção "Viu eles por aí?" -->
            <section>
                <h2 class="section-title">Viu eles por aí? Avise o tutor</h2>
                <div class="row">
                    <!-- Pet 1 -->
                    <div class="col-md-3">
                        <div class="pet-card">
                            <img src="https://images.unsplash.com/photo-1543466835-00a7907e9de1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Marshmallow">
                            <div class="pet-card-body">
                                <h5 class="pet-name">Marshmallow</h5>
                                <p class="pet-details">Cachorro, 2 anos</p>
                                <p class="pet-details">Sumiu no centro</p>
                                <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pet 2 -->
                    <div class="col-md-3">
                        <div class="pet-card">
                            <img src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Cooks">
                            <div class="pet-card-body">
                                <h5 class="pet-name">Cooks</h5>
                                <p class="pet-details">Gato, 3 anos</p>
                                <p class="pet-details">Sumiu no bairro Exxos</p>
                                <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pet 3 -->
                    <div class="col-md-3">
                        <div class="pet-card">
                            <img src="https://images.unsplash.com/photo-1583337130417-3346a1be7dee?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Marshmallow">
                            <div class="pet-card-body">
                                <h5 class="pet-name">Marshmallow</h5>
                                <p class="pet-details">Cachorro, 2 anos</p>
                                <p class="pet-details">Sumiu no centro</p>
                                <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pet 4 -->
                    <div class="col-md-3">
                        <div class="pet-card">
                            <img src="https://images.unsplash.com/photo-1537151625747-768eb6cf92b2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Cooks">
                            <div class="pet-card-body">
                                <h5 class="pet-name">Cooks</h5>
                                <p class="pet-details">Gato, 3 anos</p>
                                <p class="pet-details">Sumiu no bairro Exxos</p>
                                <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- Página de Adoção -->
    <div id="adoption-page" class="page-container hidden">
        <div class="container">
            <h1 class="section-title mt-4">Adotar animal</h1>
            
            <div class="row">
                <!-- Filtros -->
                <div class="col-md-3">
                    <div class="filter-section">
                        <h3 class="filter-title">Filtros</h3>
                        
                        <div class="filter-option">
                            <h6>Espécie</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-dog">
                                <label class="form-check-label" for="filter-dog">Cachorro</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-cat">
                                <label class="form-check-label" for="filter-cat">Gato</label>
                            </div>
                        </div>
                        
                        <div class="filter-option">
                            <h6>Porte</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-small">
                                <label class="form-check-label" for="filter-small">Pequeno</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-medium">
                                <label class="form-check-label" for="filter-medium">Médio</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-large">
                                <label class="form-check-label" for="filter-large">Grande</label>
                            </div>
                        </div>
                        
                        <div class="filter-option">
                            <h6>Idade</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-baby">
                                <label class="form-check-label" for="filter-baby">Filhote</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-young">
                                <label class="form-check-label" for="filter-young">Jovem</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-adult">
                                <label class="form-check-label" for="filter-adult">Adulto</label>
                            </div>
                        </div>
                        
                        <div class="filter-option">
                            <h6>Gênero</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-male">
                                <label class="form-check-label" for="filter-male">Macho</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="filter-female">
                                <label class="form-check-label" for="filter-female">Fêmea</label>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Lista de animais -->
                <div class="col-md-9">
                    <div class="row">
                        <!-- Animal 1 -->
                        <div class="col-md-4 mb-4">
                            <div class="pet-card" onclick="showAnimalDetail('Max')">
                                <img src="https://images.unsplash.com/photo-1554692918-08fa0fdc9db3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Max">
                                <div class="pet-card-body">
                                    <h5 class="pet-name">Max</h5>
                                    <p class="pet-details">Cachorro, 2 anos</p>
                                    <p class="pet-details">Porte médio, pelagem longa</p>
                                    <p class="pet-details"><strong>Mundo dos Pets Adoráveis</strong></p>
                                    <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Animal 2 -->
                        <div class="col-md-4 mb-4">
                            <div class="pet-card" onclick="showAnimalDetail('Luna')">
                                <img src="https://images.unsplash.com/photo-1513360371669-4adf3dd7dff8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Luna">
                                <div class="pet-card-body">
                                    <h5 class="pet-name">Luna</h5>
                                    <p class="pet-details">Gata, 5 anos</p>
                                    <p class="pet-details">Porte pequeno, pelagem curta</p>
                                    <p class="pet-details"><strong>Mundo dos Pets Adoráveis</strong></p>
                                    <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Animal 3 -->
                        <div class="col-md-4 mb-4">
                            <div class="pet-card" onclick="showAnimalDetail('Bobby')">
                                <img src="https://images.unsplash.com/photo-1587300003388-59208cc962cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Bobby">
                                <div class="pet-card-body">
                                    <h5 class="pet-name">Bobby</h5>
                                    <p class="pet-details">Cachorro, 3 anos</p>
                                    <p class="pet-details">Porte grande, pelagem média</p>
                                    <p class="pet-details"><strong>Mundo dos Pets Adoráveis</strong></p>
                                    <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Animal 4 -->
                        <div class="col-md-4 mb-4">
                            <div class="pet-card" onclick="showAnimalDetail('Mia')">
                                <img src="https://images.unsplash.com/photo-1533738363-b7f9aef128ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Mia">
                                <div class="pet-card-body">
                                    <h5 class="pet-name">Mia</h5>
                                    <p class="pet-details">Gata, 1 ano</p>
                                    <p class="pet-details">Porte pequeno, pelagem longa</p>
                                    <p class="pet-details"><strong>Mundo dos Pets Adoráveis</strong></p>
                                    <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Animal 5 -->
                        <div class="col-md-4 mb-4">
                            <div class="pet-card" onclick="showAnimalDetail('Thor')">
                                <img src="https://images.unsplash.com/photo-1548199973-03cce0bbc87b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Thor">
                                <div class="pet-card-body">
                                    <h5 class="pet-name">Thor</h5>
                                    <p class="pet-details">Cachorro, 4 anos</p>
                                    <p class="pet-details">Porte médio, pelagem curta</p>
                                    <p class="pet-details"><strong>Mundo dos Pets Adoráveis</strong></p>
                                    <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Animal 6 -->
                        <div class="col-md-4 mb-4">
                            <div class="pet-card" onclick="showAnimalDetail('Nina')">
                                <img src="https://images.unsplash.com/photo-1513360371669-4adf3dd7dff8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Nina">
                                <div class="pet-card-body">
                                    <h5 class="pet-name">Nina</h5>
                                    <p class="pet-details">Cachorra, 2 anos</p>
                                    <p class="pet-details">Porte pequeno, pelagem longa</p>
                                    <p class="pet-details"><strong>Mundo dos Pets Adoráveis</strong></p>
                                    <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Paginação -->
                    <nav aria-label="Navegação de páginas">
                        <ul class="pagination pagination-custom justify-content-center">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1">Anterior</a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Próximo</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <!-- Página de Detalhes do Animal -->
    <div id="animal-detail-page" class="page-container hidden">
        <div class="container">
            <button class="btn btn-secondary mt-4 mb-3" onclick="showPage('adoption-page')">
                <i class="bi bi-arrow-left"></i> Voltar para adoção
            </button>
            
            <div class="animal-detail-section">
                <div class="row">
                    <div class="col-md-6">
                        <img src="https://images.unsplash.com/photo-1554692918-08fa0fdc9db3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Max" class="animal-image">
                    </div>
                    <div class="col-md-6">
                        <h1 class="animal-name">Max</h1>
                        
                        <div class="animal-info">
                            <p><span class="info-label">Idade:</span> 2 anos</p>
                            <p><span class="info-label">Espécie:</span> Cachorro</p>
                            <p><span class="info-label">Porte:</span> Médio</p>
                            <p><span class="info-label">Pelagem:</span> Longa</p>
                            <p><span class="info-label">ONG:</span> Mundo dos Pets Adoráveis</p>
                            <p><span class="info-label">Localização:</span> São Paulo, SP</p>
                        </div>
                        
                        <div class="animal-description">
                            <h5 class="info-label">Sobre Max</h5>
                            <p>Que cara adorável! Max é um cão cheio de energia e amor para dar. Seus olhos expressivos conquistam a todos, porém não foram afetados pela vida nas ruas. Sempre com amor incondicional, ele espera por uma família que possa dar a ele o lar que merece. Este amigo de quatro patas está pronto para fazer parte da sua família e trazer alegria para sempre.</p>
                        </div>
                        
                        <div class="mt-4">
                            <button class="btn btn-primary-custom me-2">Entrar em contato</button>
                            <button class="btn btn-outline-primary">Compartilhar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Página de Perfil -->
    <div id="profile-page" class="page-container hidden">
        <div class="container">
            <h1 class="section-title mt-4">Meu Perfil</h1>
            
            <div class="row">
                <div class="col-md-4">
                    <div class="animal-detail-section text-center">
                        <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80" alt="Foto de perfil" class="rounded-circle mb-3" width="150" height="150">
                        <h3>Yan Cardoso</h3>
                        <p class="text-muted">Tutor</p>
                        <button class="btn btn-primary-custom btn-sm">Editar perfil</button>
                    </div>
                    
                    <div class="animal-detail-section mt-4">
                        <h5 class="info-label mb-3">Minhas informações</h5>
                        <p><i class="bi bi-envelope me-2"></i> yancardoso@outlook.com.br</p>
                        <p><i class="bi bi-telephone me-2"></i> (19) 99999-9999</p>
                        <p><i class="bi bi-geo-alt me-2"></i> Rua das Flores, 9999</p>
                        <p><i class="bi bi-building me-2"></i> São José do Vale do Rio Preto, SP</p>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <div class="animal-detail-section">
                        <h5 class="info-label mb-3">Meus animais</h5>
                        
                        <div class="row">
                            <!-- Animal 1 -->
                            <div class="col-md-6 mb-4">
                                <div class="pet-card">
                                    <img src="https://images.unsplash.com/photo-1543466835-00a7907e9de1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Rex">
                                    <div class="pet-card-body">
                                        <h5 class="pet-name">Rex</h5>
                                        <p class="pet-details">Cachorro, 4 anos</p>
                                        <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Animal 2 -->
                            <div class="col-md-6 mb-4">
                                <div class="pet-card">
                                    <img src="https://images.unsplash.com/photo-1513360371669-4adf3dd7dff8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" alt="Mimi">
                                    <div class="pet-card-body">
                                        <h5 class="pet-name">Mimi</h5>
                                        <p class="pet-details">Gata, 2 anos</p>
                                        <button class="btn btn-primary-custom btn-sm">Ver detalhes</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="animal-detail-section mt-4">
                        <h5 class="info-label mb-3">Minhas adoções</h5>
                        <p>Você ainda não adotou nenhum animal através da nossa plataforma.</p>
                        <button class="btn btn-primary-custom" onclick="showPage('adoption-page')">Encontrar um pet</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container text-center">
            <p>&copy; 2025 Mundo dos Pets Adoráveis. Todos os direitos reservados.</p>
            <p>Ajude na busca pelo amigo perdido de alguém ❤️</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Função para mostrar a página selecionada e esconder as outras
        function showPage(pageId) {
            // Esconder todas as páginas
            document.querySelectorAll('.page-container').forEach(page => {
                page.classList.add('hidden');
            });
            
            // Mostrar a página selecionada
            document.getElementById(pageId).classList.remove('hidden');
        }
        
        // Função para mostrar detalhes do animal
        function showAnimalDetail(animalName) {
            // Aqui você poderia carregar os dados específicos do animal selecionado
            // Por enquanto, vamos apenas mostrar a página de detalhes
            showPage('animal-detail-page');
            
            // Atualizar o nome do animal na página de detalhes
            document.querySelector('.animal-name').textContent = animalName;
        }
        
        // Inicializar a página principal
        document.addEventListener('DOMContentLoaded', function() {
            showPage('home-page');
        });
    </script>
</body>
</html>